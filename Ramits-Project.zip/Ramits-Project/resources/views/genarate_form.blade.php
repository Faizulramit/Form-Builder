<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Genarate Form</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Form Builder</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav" style="margin-left:80%">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="/"><b>Home</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="{{route('genarate_form')}}"><b>Genarate Form</b></a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container p-5">
    <div class="row">
        <div class="col">
          <form action="{{route('store')}}" method="post">
            @csrf
              <label class="from-group" for="">From Name</label><br>
              <input class="from-group" name="from_name" type="text">
              <div class="row-4 mt-3" id="text">
                  <label class="from-group" for="">Text</label><br>
                  <input class="from-group" name="text" type="text">
              </div>
              <div class="row-4 mt-3" id="number">
                  <label class="from-group" for="">Number</label><br>
                  <input class="from-group" name="number" type="text">
              </div>
              <div class="row-4 mt-3" id="date">
                  <label class="from-group" for="">Date</label><br>
                  <input class="from-group" name="date" type="text">
              </div>
              <div class="row-4 mt-3"id="text_area">
                  <label class="from-group" for="">Text Area</label><br>
                  <input class="from-group" name="text_area" type="text">
              </div>
              <div class="row-4 mt-3" id="genarate_button">
                  <button type="submit" class="btn btn-success from-group">Genarate</button>
              </div>
          </form>
        </div>
        <div class="col" style="text-align:right;">
            <ul style="list-style:none;">
                <li id="text_btn" class=""><button class="btn btn-success">Text</button></li>
                <li id="number_btn" class="mt-2"><button class="btn btn-success">Number</button></li>
                <li id="date_btn" class="mt-2"><button class="btn btn-success">Date</button></li>
                <li id="text_area_btn" class="mt-2"><button class="btn btn-success">Text Area</button></li>
            </ul>
           
        </div>
    </div>
</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
      $("#text").hide();
      $("#number").hide();
      $("#date").hide();
      $("#text_area").hide();
      $("#genarate_button").hide();

      $("#text_btn").click(function(){
        $("#text").show();
        $("#genarate_button").show();

      });
      $("#number_btn").click(function(){
        $("#number").show();
        $("#genarate_button").show();
      });
      $("#date_btn").click(function(){
        $("#date").show();
        $("#genarate_button").show();
      });
      $("#text_area_btn").click(function(){
        $("#text_area").show();
        $("#genarate_button").show();
      });
    });
    </script>
  </body>
</html>